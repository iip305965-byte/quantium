#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;
// Rounded scoreboard (sidebar) background:
out vec2 cornerUV;        // 0..1 inside the rectangle
out vec2 guiPos;          // GUI pixel coords, used to get GUI scale
flat out int roundMode;   // 0 none, 1 round top (title), 2 round bottom (body)

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    guiPos = Position.xy;

    // every GUI rectangle is 4 consecutive vertices
    int c = gl_VertexID % 4;
    cornerUV = vec2((c == 2 || c == 3) ? 1.0 : 0.0, (c == 1 || c == 2) ? 1.0 : 0.0);

    // Sidebar background: black, alpha 0.4 (title) / 0.3 (lines), right half of screen
    roundMode = 0;
    int a = int(Color.a * 255.0 + 0.5);
    if (Color.r == 0.0 && Color.g == 0.0 && Color.b == 0.0 && gl_Position.x > 0.0) {
        if (a == 102) roundMode = 1;
        else if (a == 76) roundMode = 2;
    }
}
