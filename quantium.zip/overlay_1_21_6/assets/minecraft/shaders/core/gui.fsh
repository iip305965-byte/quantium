#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
in vec2 cornerUV;
in vec2 guiPos;
flat in int roundMode;

out vec4 fragColor;

// Corner radius in GUI pixels
const float RADIUS = 3.0;

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }

    if (roundMode != 0) {
        // Vertex order is unknown - align uv to screen using derivatives:
        // u grows right, v grows down.
        vec2 uv = cornerUV;
        vec2 dx = dFdx(uv);
        vec2 dy = dFdy(uv);
        if (abs(dx.x) < abs(dx.y)) {
            uv = uv.yx; dx = dx.yx; dy = dy.yx;
        }
        if (dx.x < 0.0) uv.x = 1.0 - uv.x;
        if (dy.y > 0.0) uv.y = 1.0 - uv.y; // window y is up, GUI y is down

        vec2 size = vec2(1.0 / max(abs(dx.x), 1e-6), 1.0 / max(abs(dy.y), 1e-6)); // size in screen pixels
        vec2 p = uv * size;
        float scale = 1.0 / max(abs(dFdx(guiPos.x)), 1e-6); // screen pixels per GUI pixel
        float r = RADIUS * scale;

        float ex = min(p.x, size.x - p.x);
        float ey = roundMode == 1 ? p.y : size.y - p.y;
        if (ex < r && ey < r) {
            float d = length(vec2(r - ex, r - ey));
            float aa = clamp(r - d + 0.5, 0.0, 1.0);
            if (aa <= 0.0) {
                discard;
            }
            color.a *= aa;
        }
    }

    fragColor = color * ColorModulator;
}
